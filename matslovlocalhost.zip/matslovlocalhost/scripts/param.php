﻿<?php
$host = 'localhost';     
$database = 'termin';     
$user = 'root';             
$password = '';   
?>

<?php
function startSession($isUserActivity=true) {
  
	$sessionLifetime = 1800;
	$idLifetime = 60;   // Время жизни идентификатора сессии

	$t = time();
        // Если время жизни идентификатора сессии задано,
		// проверяем время, прошедшее с момента создания сессии или последней регенерации
		// (время последнего запроса, когда была обновлена сессионная переменная starttime)
	if ( $sessionLifetime ) {
		if ( isset($_SESSION['lastactivity']) && $t-$_SESSION['lastactivity'] >= $sessionLifetime ) {
			destroySession();
			return false;
		}
		else {
			if ( $isUserActivity ) $_SESSION['lastactivity'] = $t;
		}
	}

	if ( $idLifetime ) {
		if ( isset($_SESSION['starttime']) ) {
			if ( $t-$_SESSION['starttime'] >= $idLifetime ) {
			 // Время жизни идентификатора сессии истекло
				// Генерируем новый идентификатор
				session_regenerate_id(true);
				$_SESSION['starttime'] = $t;
			}
		}
		else {
		  // Сюда мы попадаем, если сессия только что создана
			// Устанавливаем время генерации идентификатора сессии в текущее время
			$_SESSION['starttime'] = $t;
		}
	}

	return true;
}

function destroySession() {
	if ( session_id() ) {
		session_unset();
		setcookie(session_name(), session_id(), time()-60*60*24);
		session_destroy();
	}
}

?>
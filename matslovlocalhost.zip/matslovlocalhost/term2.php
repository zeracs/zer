<html>
  <head>
         <meta charset="utf-8">
         <title>Математические термины</title>
          
         <link rel="stylesheet" href="style/menu.css"> 
         <link rel="stylesheet" href="style/window_term2.css">
          <link rel="stylesheet" href="style/window_off.css">
         
  </head>
 <body background='data/fon/background1.png'>   
 <?php


         require_once 'scripts/param.php';                  // подключаем параметры сеанса работы с базой
// открываем базу
         $link = mysqli_connect($host, $user, $password, $database) or die("Ошибка" .mysqli_connect_error($link));
         
          if (!mysqli_set_charset($link, "utf8")) {
    printf("Ошибка при загрузке набора символов utf8: %s\n", mysqli_error($link));
    exit();}     
         
  echo "<div id='razrab' class='modalDialog1'><div><a href='#close1' title='Закрыть' class='close1'>X</a>";
echo "<center><b><font align='center' size=5>Разработчики электронного словаря русско-тувинских математических терминов</b></center></font><br>";
echo "<table width=100%>
      <tr><td>Исполнитель</td><td>студент 5 курса бакалавриата по направлению 'Педагогическое образование' с двумя профилями подготовки 'Математика' и 'Информатика'  Михалев Петр Андреевич</td></tr>
      <tr><td>Научный руководитель</td><td>доц., к.ф.-м.н. Далаа Сергей Монгушевич</td></tr></table>";
echo"</div> </div>";        
         
         
echo "<div id='info' class='modalDialog2'><div><a href='#close2' title='Закрыть' class='close2'>X</a>";
echo "<center><b><font align='center' size=3>Просмотр математического термина № - ",$_POST['ind']," </b></font></center><br>";
echo "<table>
 <form  method = 'post' enctype='multipart/form-data'>
 <input name='ind' type=hidden value='", $i,"'>;
 <tr><input type='hidden' name='ID' size='20' value=",$_POST['ID']," readonly>
  <td><b>Термин:</b></td><td><textarea name='Name' rows='10' cols='50' readonly>",$_POST['Name'],"</textarea></td>
   <td><b>Тувинский:</b></td><td><textarea name='Name_Tuv' rows='10' cols='50' readonly>",$_POST['Name_Tuv'],"</textarea></td>"; 
   
   
          {if ($_POST['Picture'] <> '')
                 { if (file_exists("data/pictures/".$_POST['Picture']))
                  {echo "<td><b>Рисунок:</b></td>
   <td><input name='Picture' type='hidden' value=", $_POST['Picture'],"><br>
                  <a href='/data/pictures/", $_POST['Picture'],"' target='_blank'><input type='button' value='Показать'><br><br></a>";
                  }
                  else {echo "<td></td>
   <td><input name='Picture' type='hidden' value=", $_POST['Picture'],"><br>
                  <a href='/data/pictures/", $_POST['Picture'],"' target='_blank'><input type='hidden' value='Показать'><br><br></a>";
                  }}}

  echo "</td></tr>
   
    <tr><td><b>Определение:</b></td><td><textarea name='Znach' rows='10' cols='50' readonly>",$_POST['Znach'],"</textarea></td>
     <td><b>Тувинский:</b></td><td><textarea name='Znach_Tuv' rows='10' cols='50' readonly>",$_POST['Znach_Tuv'],"</textarea></td>
       <td><b>Редактор:</b></td><td><input type='text' name='Avtor' rows='10' cols='30' value='",$_POST['Avtor'],"' readonly></td></tr>
 <tr><td colspan=6 align='center'><br><input type='submit',  name='OK', value='Закрыть' formaction='term2.php#close2'><br></td></tr>
 </form></table>";
echo"</div> </div>";
 
 

if ( ( $_POST['search'] != '') && ( $_POST['search1'] != '')){

if (isset($_POST['search']) || isset($_POST['search1'])){
 echo" <ul id='menu'>
      <li><a href='index.php'>Главная</a></li>
      <li><a href='index.php#log'>Редактирование</a></li>
      <li><a href='#razrab'>Разработчики</a></li>
      <div class='auser'><form method='POST' action='term2.php'>
<input type='search' placeholder='Поиск…' value='' name='search' size='30'>   <input type='submit' value='Найти' name='search1'></form></div>
<div class='auser'><a href='term2.php'>Вернуться к просмотру</a></div>
</ul>";


$sea = mysqli_real_escape_string($link, $_POST['search'].'*');
    // работа с базой данных
 
         $query1   = "ALTER TABLE termin ADD FULLTEXT (Name, Name_Tuv, Znach, Znach_Tuv)";
         $query2   = "SELECT * FROM termin WHERE MATCH (Name, Name_Tuv, Znach, Znach_Tuv) AGAINST ('$sea' IN BOOLEAN MODE) ORDER BY termin.Name ASC;";    
        
         mysqli_query( $link,  $query1 );
         $result  =  mysqli_query( $link,  $query2 );
       
         $count  =  mysqli_num_rows($result);
        echo "<br><center><b><font align='center' size=5>Поиск терминов по совпадениям</b></center></font><br>";
     // цикл по результирующему набору, пока не закончатся записи в наборе
          echo "<table border=1 bordercolor='green' width='100%'>
         <caption><td  align='center' colspan=7><font size=5><b>Найдено всего совпадений - ",$count,"</b></font></td></caption>
         <tr><td>№</td>
         <td align='center'>Термин</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Определение</td>
         <td align='center'>Тувинский</td>
         <td align='center'></td>
         </tr>";
         for ($i=1; $i<=$count; $i++) {
          $row = mysqli_fetch_assoc($result);
            $id = mysqli_real_escape_string($link, $row['ID']);
           echo "<tr><form method='POST'>";
                  echo "<input name='ind' type=hidden value='", $i,"'>";
                  echo " <td><input name='ID' type=hidden value='", $row['ID'],"'>", $i,"</td>";
                  echo " <td><input name='Name' type=hidden value='", $row['Name'],"'>", $row['Name'],"</td>";   
                  echo " <td><input name='Name_Tuv' type=hidden value='", $row['Name_Tuv'],"'>", $row['Name_Tuv'],"</td>";
                  echo " <td><input name='Znach' type=hidden value='", $row['Znach'],"'>", $row['Znach'],"</td>";
                  echo " <td><input name='Znach_Tuv' type=hidden value='", $row['Znach_Tuv'],"'>", $row['Znach_Tuv'],"</td>";
                  echo "<td>
                        <input name='Picture' type=hidden value='", $row['Picture'],"'>
                        <input name='Avtor' type=hidden value='", $row['Avtor'],"'>
                        <input type='submit' name='rrr' value='Подробнее' formaction='term2.php#info'></td></form></tr>";
                 
         }
        echo "</table>";
         
}}
else {
   echo" <ul id='menu'>
      <li><a href='index.php'>Главная</a></li>
      <li><a href='index.php#log'>Редактирование</a></li>
      <li><a href='#razrab'>Разработчики</a></li>
      <div class='auser'><form method='POST' action='term2.php'>
<input type='search' placeholder='Поиск…' value='' name='search' size='30'>  <input type='submit' value='Найти' name='search1'></form></div>
</ul>";



// работа с базой данных
         $query   =  "SELECT * FROM termin ORDER BY termin.Name ASC";     $result  =  mysqli_query( $link,  $query );
         $count  =  mysqli_num_rows($result);

echo "<br><center><b><font align='center' size=5>Электронный словарь русско-тувинских математических терминов</b></center></font><br>";

     // цикл по результирующему набору, пока не закончатся записи в наборе
         echo "<table border=1 bordercolor='green' width='100%'>
         <caption><td  align='center' colspan=7><font size=5><b>Математические термины (всего - ",$count,")</b></font></td></caption>
         <tr><td>№</td>
         <td align='center'>Термин</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Определение</td>
         <td align='center'>Тувинский</td>
         <td align='center'></td>
         </tr>";
         for ($i=1; $i<=$count; $i++) {
          $row = mysqli_fetch_assoc($result);
            $id = mysqli_real_escape_string($link, $row['ID']);
           echo "<tr><form method='POST'>";
                  echo "<input name='ind' type=hidden value='", $i,"'>";
                  echo " <td><input name='ID' type=hidden value='", $row['ID'],"'>", $i,"</td>";
                  echo " <td><input name='Name' type=hidden value='", $row['Name'],"'>", $row['Name'],"</td>";   
                  echo " <td><input name='Name_Tuv' type=hidden value='", $row['Name_Tuv'],"'>", $row['Name_Tuv'],"</td>";
                  echo " <td><input name='Znach' type=hidden value='", $row['Znach'],"'>", $row['Znach'],"</td>";
                  echo " <td><input name='Znach_Tuv' type=hidden value='", $row['Znach_Tuv'],"'>", $row['Znach_Tuv'],"</td>";
                  echo "<td>
                        <input name='Picture' type=hidden value='", $row['Picture'],"'>
                        <input name='Avtor' type=hidden value='", $row['Avtor'],"'>
                        <input type='submit' name='rrr' value='Подробнее' formaction='term2.php#info'></td></form></tr>";
                 
         }
        echo "</table>";}






 
                 

         mysqli_free_result($result);           // очищаем память
         mysqli_close($link);                       // закрываем базу

?>
  </body>
</html>
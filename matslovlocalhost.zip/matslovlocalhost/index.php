<?php
 require_once 'scripts/func.php';
 session_start();

?>

<html>
  <head>
         <meta charset="utf-8">
         <title>Главная</title>
          <link rel="stylesheet" href="style/window.css">
          <link rel="stylesheet" href="style/window_off.css">
          <link rel="stylesheet" href="style/abz.css">
  </head>
   
  <style>
      .zgl { font-size:80; color: green }
      .shr2 { font-size:32; text-align: center }
      .shr3 { font-size:42; text-align: center }
      .shr_kn { font-size:18;  font-weight:bold }
    </style>

  <body background='data/fon/background24.png'>
  
  
 <?php 
 echo "<div id='log' class='modalDialog'>
    <div>";
 echo "<a href='#close' title='Закрыть' class='close'>X</a>";
 
  if (empty($_SESSION['use1']) && empty($_SESSION['pass1']))
{
 echo "<center><b><font align='center' size=4>Вход в режим редактирования</b></center></font><br>";
 echo "
 <form method='POST'  >
 <center><b>Логин:</b><input type='text' name='use' size='20' required><br><br>
 <b>Пароль:</b><input type='password' name='pass' size='20' required><br><br>
 <input type='submit' name='login' value='Войти'>
 <input type='reset' name='delete' value='Очистить'></center>
 </form>"; 
  
if (isset($_POST['login'])) 
{   require_once 'scripts/param.php';
    $link = mysqli_connect($host, $user, $password, $database) or die("Ошибка" .mysqli_connect_error($link));
    
     if (!mysqli_set_charset($link, "utf8")) {
    printf("Ошибка при загрузке набора символов utf8: %s\n", mysqli_error($link));
    exit();}     
    
    $_SESSION['use1'] = $_POST['use'];
    $_SESSION['pass1'] = $_POST['pass'];
    $use = mysqli_real_escape_string($link, $_SESSION['use1']);
    $pass = mysqli_real_escape_string($link, $_SESSION['pass1']);
    $query = "SELECT passes FROM users WHERE useres='$use'"; 
    $result = mysqli_query($link,  $query );
    $row = mysqli_fetch_assoc($result);

    {if ($row['passes']==$pass) 
     {echo "<center>ДАННЫЕ ВВЕДЕНЫ ВЕРНО!</center>"; 
     echo $row['useres'];
     
    echo "<script>document.location.replace('term1.php#user')</script>"; 
     }  
    else 
       {session_unset();
       	echo "<center>ЛОГИН И/ИЛИ ПАРОЛЬ ВВЕДЕНЫ НЕ ВЕРНО!</center>";}}
         mysqli_free_result($result);         
         mysqli_close($link);
}}

 else {require_once 'scripts/param.php';
                                           // require_once "scripts/pw.php";   //проверка существования логина и пароля в сессиях
       $link = mysqli_connect($host, $user, $password, $database) or die("Ошибка" .mysqli_connect_error($link));
       $use = mysqli_real_escape_string($link, $_SESSION['use1']);    
       $query = "SELECT avtores, passes FROM users WHERE useres='$use'"; 
       $result = mysqli_query($link,  $query );
       $row = mysqli_fetch_assoc($result);
       echo "<center>Вы, <b>", $row['avtores'], "</b>, уже вошли, как редактор.<br> 
                     Хотите продолжить редактирование?<br><br>
            <form method='POST'>
            <input type='submit' name='continue' value='Да'>
            <input type='submit' name='cancl' value='Нет'>
            </form>
            <center>";
      mysqli_free_result($result);         
      mysqli_close($link);
         
if (isset($_POST['continue']))
echo "<script>document.location.replace('term1.php')</script>";  

 if (isset($_POST['cancl'])) 
 {destroySession();      //удаление файла pw.php из папки scripts/
  echo "<script>document.location.replace('main.php')</script>";}  
} 

 echo"</div> </div>";

 echo "<div id='annot' class='modalDialog1'>
    <div>";
echo "<a href='#close1' title='Закрыть' class='close1'>X</a>";
echo "<center><b><font align='center' size=5>Аннотация</b></center></font><br>";
echo "<p>В базе данных содержатся математические термины, составляющих школьный курс математики. Составленный список математических терминов, входящих в курс элементарной математики, алгебры и геометрии, позволит систематизировать знания школьников по программе математики 5–11 классов. 
База данных предназначена для учащихся школ Республики Тыва с целью повышения качества знаний по математике на основе использования переведенных математических терминов с русского на тувинский язык. По каждому термину база данных содержит толкование, что позволит учащимся осознанно изучить теоретический материал и применять при решении математических задач. Базу данных также можно использовать для обучения математике детей с ограниченными возможностями здоровья.
Данная база является первым опытом представления и систематизации математических терминов на тувинском языке для школьников.
База данных может быть полезна и для учителей и методистов в процессе преподавания математики.</p>";

echo "<table><caption>Авторы словаря</caption>
      <tr><td><img src='data/photo/1.jpg'></td><td><img src='data/photo/2.jpg'></td><td><img src='data/photo/3.jpg'></td><td><img src='data/photo/5.jpg'></td></tr>
      <tr><td>к.п.н., доцент Танзы Менги Васильевна</td><td>ст. преп., Танова Оксана Монгушовна</td><td>к.п.н., доцент Монгуш Айлана Севеновна</td><td>к.п.н., доцент Кара-Сал Надежда Маасовна</td></tr></table>
";
echo"</div> </div>";
 
 
echo "<div id='help' class='modalDialog1'><div>";
echo "<a href='#close1' title='Закрыть' class='close1'>X</a>";
echo "<center><b><font align='center' size=5>Помощь</b></center></font><br>";
echo "<p>Данный электронный словарь представляет собой web-приложение. Чтобы им пользоваться информируем вас о назначении кнопок.</p>";
echo "<table width=100%><tr><td>Содержание</td><td>На данной странице содержится информация о математических терминах.</td></tr>
     <tr><td>Режим редактирования</td><td>Дает доступ к редактированию словаря, после ввода логина и пароля. (Режим администатора).</td></tr>
     <tr><td>Аннотация</td><td>Содержит информацию о авторах русско-тувинского словаря математических терминов.</td></tr></table>";
echo"</div> </div>";


?>
    <table width='100%' height='100%' align='center' CELLSPACING='1' CELLPADDING='1' BORDER='0'>
      <tr><td class='shr2' colspan='6' valign='top'>
          <br> ТУВИНСКИЙ ГОСУДАРСТВЕННЫЙ УНИВЕРСИТЕТ
          <br>КАФЕДРА АЛГЕБРЫ И ГЕОМЕТРИИ
          <br>КАФЕДРА МАТЕМАТИЧЕСКОГО АНАЛИЗА И МПМ
          <br>КАФЕДРА ИНФОРМАТИКИ
        </td>
      </tr>
      <tr><td class='shr3' colspan='6'>Танзы М. В., Танова О. М., Кара-Сал Н. М., Монгуш А. С.</td></tr>
      <tr><td class='zgl' colspan='6'>
<div align='center'>Электронный словарь русско-тувинских математических терминов</div>
        </td>
      </tr>
      <tr><td class='shr2' colspan='6'>Электронный словарь</td></tr>
      <tr><td class=shr2 colspan=6>Кызыл 2019</td></tr>
      <tr>
        <form>
          <td>
            <input class='shr_kn' type='Button' value='Содержание' name='teor' onClick='location.href="term2.php"'>
          <td>
            <input class='shr_kn' type='Button' value='Режим редактирования' name='edit' onClick='location.href="#log"'>
          </td>
          <td>
            <input class='shr_kn' type='Button' value='Аннотация' name='Spr1' onClick='location.href="#annot"'>
          </td>
          <td align='right'>
            <input class='shr_kn' type='Button' value='Помощь' name='Spr2asd' onClick='location.href="#help"'>
          </td>
        </form>
      </tr>
    </table>
  </body>
</html>
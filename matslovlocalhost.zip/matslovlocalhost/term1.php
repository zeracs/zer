<?php
 require_once 'scripts/func.php';
 session_start();
 startSession($isUserActivity=true);   
?>
<html>
  <head>
         <meta charset="utf-8">
         <title>Редактирование математических терминов</title>
          
         <link rel="stylesheet" href="style/menu.css"> 
         <link rel="stylesheet" href="style/window.css">
         <link rel="stylesheet" href="style/window_off.css">
         <link rel="stylesheet" href="style/window_term2.css">
  </head>
 <body background='data/fon/background8.gif'>   
<?php

   
          require_once 'scripts/param.php';                  // подключаем параметры сеанса работы с базой
// открываем базу
         $link = mysqli_connect($host, $user, $password, $database) or die("Ошибка" .mysqli_connect_error($link));

     if (!mysqli_set_charset($link, "utf8")) {
    printf("Ошибка при загрузке набора символов utf8: %s\n", mysqli_error($link));
    exit();}     
    
    if (!empty($_SESSION['pass1']) && !empty($_SESSION['use1']))
    {//require_once 'scripts/pw.php'; 
    $use = mysqli_real_escape_string($link, $_SESSION['use1']);
    $query = "SELECT passes, avtores FROM users WHERE useres='$use'"; 
    $z = mysqli_query($link,  $query );
    $r = mysqli_fetch_assoc($z);
        
        if ($r['passes']==$_SESSION['pass1']) 
     {  



// разработчики
echo "<div id='razrab' class='modalDialog1'><div><a href='#close1' title='Закрыть' class='close1'>X</a>";  
echo "<center><b><font align='center' size=5>Разработчики электронного словаря русско-тувинских математических терминов</b></center></font><br>";
echo "<table width=100%>
      <tr><td>Исполнитель</td><td>студент 5 курса бакалавриата по направлению 'Педагогическое образование' с двумя профилями подготовки 'Математика' и 'Информатика'  Михалев Петр Андреевич</td></tr>
      <tr><td>Научный руководитель</td><td>доц., к.ф.-м.н. Далаа Сергей Монгушевич</td></tr></table>";
echo"</div> </div>"; 

//выход из учетной записи  
echo "<div id='exit' class='modalDialog'><div><a href='#close' title='Закрыть' class='close'>X</a>";
 echo "<center><b><font align='center' size=4>Выход из режима редактирования</b></center></font><br>";
 echo "
 <form method='POST'  >
 <center><b>Вы действительно хотите выйти?</b><br><br>
 <input type='submit' name='ex' value='Выйти'>
 <input type='submit' value='Нет' formaction='#close'></center>
 </form>";
 
 if (isset($_POST['ex'])) {
{
destroySession();      //удаление сессии
echo "<script>document.location.replace('index.php')</script>";
}}  
 
echo"</div> </div>"; 
 

echo "<div id='addedt' class='modalDialog'><div><a href='#close' title='Закрыть' class='close'>X</a>";
echo "<center><font size=4>";
if (isset($_POST['termadd'])){
echo $_POST['termadd'];}
echo "</font></b><br><br><a href='term1.php'><input type='button' value='ОК'></a>  </center>";
echo"</div> </div>";  



//добавление записи

echo "<div id='addition' class='modalDialog2'><div><input type='submit' form='add1' name='extadd' class='close2' title='Закрыть' value='X' formaction='term1.php'>";
echo "<center><b><font align='center' size=5>Добавление математического термина</font></b></center>";
if (isset($_POST['add'])) {
$Name = mysqli_real_escape_string($link, $_POST['Name']);
$Name_Tuv = mysqli_real_escape_string($link, $_POST['Name_Tuv']);
$Znach = mysqli_real_escape_string($link, $_POST['Znach']);
$Znach_Tuv = mysqli_real_escape_string($link, $_POST['Znach_Tuv']);
$Avtor = mysqli_real_escape_string($link, $_POST['Avtor']);
$query = "INSERT INTO termin (Name, Name_Tuv, Znach, Znach_Tuv, Picture, Avtor, delPicture) 
          VALUES ('$Name', '$Name_Tuv', '$Znach', '$Znach_Tuv', '' , '$Avtor', '')"; 
           
  if (mysqli_query($link, $query)<> FALSE)
   { echo "Математический термин добавлен!";
    
  
  $ID = mysqli_insert_id($link);
  $_POST['id'] = $ID;
   
    if (file_exists($_POST['path1'])){
        $ID = $_POST['id'];
     $path1 = $_POST['path1'];
     $name = "data/temp/".$ID.'.'.$_POST['mime'];
     rename ("$path1", "$name" );
     $namez = $ID.'.'.$_POST['mime'];
     copy("data/temp/".$namez, "data/pictures/".$namez); //перемещение в папку pictures
     unlink ("data/temp/".$namez);   //удаление временного файла из папки data/temp/
     $Picture = mysqli_real_escape_string($link, $namez);
     $que = "UPDATE termin SET  
        Picture = '$Picture' 
        WHERE ID = '$ID'";
      mysqli_query($link, $que); }

 echo "<script>document.location.replace('term1.php')</script>";
  }
  else {echo "Математический термин не добавлен!";} }

if (isset($_POST['loadadd'])) {
  // разбиваем имя файла по точке и получаем массив
   $getMime = explode('.', $_FILES["filename"]["name"]);
  // нас интересует последний элемент массива - расширение
   $mime = strtolower(end($getMime));
  // объявим массив допустимых расширений
   $types = array('jpg', 'png', 'gif', 'bmp', 'jpeg');

   if(!in_array($mime, $types)){
    $_POST['rest'] = "Недопустимый тип файла";
     if ($_POST['nam1']<>'' && (file_exists("data/temp/".$_POST['nam1'])))
     {unlink ("data/temp/".$_POST['nam1']);
     $_POST['nam1'] = ''; } }
   else {
   if($_FILES["filename"]["size"] > 1024*4*1024)
   {
     $_POST['rest'] = "Размер файла превышает 4 мегабайта";
     exit;
   }
   // Проверяем загружен ли файл
   if(is_uploaded_file($_FILES["filename"]["tmp_name"]))
   {
     // Если файл загружен успешно, перемещаем его
     // из временной директории в конечную
     move_uploaded_file($_FILES["filename"]["tmp_name"], "data/temp/".$_FILES["filename"]["name"]); //перемещение во временную папку temp
     $nam1 = $_FILES["filename"]["name"];
     $path1 = "data/temp/".$_FILES["filename"]["name"];
     $_POST['nam1'] = $nam1;
     $_POST['path1'] = $path1; 
     $_POST['mime'] = $mime;
     $_POST['rest'] = "Файл загружен успешно!";
   } else {
     $_POST['rest'] = "Ошибка загрузки файла";
     $_POST['nam1'] = '';
   }}
  }



if (isset($_POST['extadd']))
{ if ($_POST['nam1']<>'' && (file_exists("data/temp/".$_POST['nam1'])))
     {unlink ("data/temp/".$_POST['nam1']);
     $_POST['nam1'] = ''; }}



echo "<table>
 <form id='add1' method = 'post' enctype='multipart/form-data'>
    <input type='hidden' name='nam1' value='",$_POST['nam1'],"'>
    <input type='hidden' name='path1' value='",$_POST['path1'],"'>
    <input type='hidden' name='mime' value='",$_POST['mime'],"'>

  <tr><input type='hidden' name='ID' size='10' readonly>
  <td><b>Термин:</b></td><td><textarea name='Name' rows='10' cols='40'></textarea></td>
   <td><b>Тувинский:</b></td><td><textarea name='Name_Tuv' rows='10' cols='40'></textarea></td>
    
    <td><b>Рисунок:</b></td>
   <td> <input type='file' name='filename'><br> 
        <input name='Picture' type='text' size='10' value='",$_POST['nam1'],"' readonly><br>";
  echo "<input type='submit' name='loadadd' value='Загрузить' formaction='#addition'><br><br>";
  if ($_POST['nam1']<>'' && (file_exists("data/temp/".$_POST['nam1']))) 
  {echo "<a href='","data/temp/".$_POST['nam1'],"' target='blank'><input type='button'  value='Показать'></a><br><br>";}
  echo $_POST['rest'];
  echo " </td></tr>
      <tr> <td><b>Определение:</b></td><td><textarea name='Znach' rows='10' cols='40'></textarea></td>
      <td><b>Тувинский:</b></td><td><textarea name='Znach_Tuv' rows='10' cols='40'></textarea></td>
       <td><b>Автор:</b></td><td><input type='text' name='Редактор' size='10' value='",$r['avtores'],"' readonly></td></tr>
 <tr><td colspan=6 align='center'><br><input type='submit',  name='add', value='Добавить' formaction='#addition'>
 <input type='submit' name='extadd' value='Вернуться назад' formaction='term1.php'>
 </td></tr>
 </form></table>";
 
echo"</div> </div>"; 

//редактирование
echo "<div id='edt' class='modalDialog2'><div><input form='edqq' class='close2' type='submit' name='extedt' value='X' formaction='term1.php'>";
echo "<center><b><font align='center' size=5>Редактирование математического термина № - ",$_POST['ind'],"</b></center></font><br>";
if (isset($_POST['save'])) {
$ID =  $_POST['ID'];  
$delPicture = $_POST['delPicture'];
$Name = mysqli_real_escape_string($link, $_POST['Name']);
$Name_Tuv = mysqli_real_escape_string($link, $_POST['Name_Tuv']);
$Znach = mysqli_real_escape_string($link, $_POST['Znach']);
$Znach_Tuv = mysqli_real_escape_string($link, $_POST['Znach_Tuv']);
$Avtor = mysqli_real_escape_string($link, $_POST['Avtor']);
$query = "UPDATE termin SET  
         Name = '$Name', 
         Name_Tuv = '$Name_Tuv', 
         Znach = '$Znach', 
         Znach_Tuv ='$Znach_Tuv',
         delPicture = '',
         Avtor = '$Avtor' 
         WHERE ID = '$ID'";
  mysqli_query($link, $query);

  if (mysqli_query($link, $query)<> FALSE)
   { echo "Изменения успешно внесены";
  
    copy("data/temp/".$_POST['Picture'], "data/pictures/".$_POST['Picture']); //перемещение в папку pictures
    unlink ("data/temp/".$_POST['Picture']);   //удаление временного файла из папки data/temp/

  if (file_exists("data/del/".$delPicture) && $delPicture<>''){unlink ("data/del/".$delPicture); } 
  echo "<script>document.location.replace('term1.php')</script>";}}

if (isset($_POST['load'])) {
$ID =  $_POST['ID'];  

  // разбиваем имя файла по точке и получаем массив
   $getMime = explode('.', $_FILES["filename"]["name"]);
  // нас интересует последний элемент массива - расширение
   $mime = strtolower(end($getMime));
  // объявим массив допустимых расширений
   $types = array('jpg', 'png', 'gif', 'bmp', 'jpeg');

   if(!in_array($mime, $types))
    $_POST['rest'] = "Недопустимый тип файла";
   else {
   if($_FILES["filename"]["size"] > 1024*4*1024)
   {
     $_POST['rest'] = "Размер файла превышает 4 мегабайта";
     exit;
   }
   // Проверяем загружен ли файл
   if(is_uploaded_file($_FILES["filename"]["tmp_name"]))
   {
     // Если файл загружен успешно, перемещаем его
     // из временной директории в конечную
     move_uploaded_file($_FILES["filename"]["tmp_name"], "data/temp/".$_FILES["filename"]["name"]); //перемещение во временную папку temp
     $_POST['rest'] = "Файл загружен успешно!";
     $zn = "data/temp/".$_FILES["filename"]["name"];
     $name = "data/temp/".$_POST['ID'].'.'.$mime;
     $namez = $_POST['ID'].'.'.$mime;
     rename ("$zn" , "$name" );
     
        
      $Picture = mysqli_real_escape_string($link, $namez);
      $query = "UPDATE termin SET  
         Picture = '$Picture' 
         WHERE ID = '$ID'";
      mysqli_query($link, $query);

   $qu   =  "SELECT Picture, delPicture FROM termin WHERE ID='$ID'";     
   $res  =  mysqli_query( $link,  $qu );
   $rw = mysqli_fetch_assoc($res); 
   $_POST['Picture'] = $rw['Picture'];
   $_POST['delPicture'] = $rw['delPicture'];
   } else {
      $_POST['rest'] = "Ошибка загрузки файла";
   }}

  }


//удаление рисунка из временной папки при редактировании
if (isset($_POST['temdelte'])) {
$ID =  $_POST['ID']; 
{if ($_POST['Picture']<>'' && file_exists("data/temp/".$_POST['Picture']))
{unlink ("data/temp/".$_POST['Picture']);      //удаление файла из папки data/pictures/
$Picture = '';
$query = "UPDATE termin SET  
         Picture = '$Picture' 
         WHERE ID = '$ID'";
  mysqli_query($link, $query);


   $qu   =  "SELECT Picture, delPicture FROM termin WHERE ID='$ID'";     
   $res  =  mysqli_query( $link,  $qu );
   $rw = mysqli_fetch_assoc($res); 
   $_POST['Picture'] = $rw['Picture'];
   $_POST['delPicture'] = $rw['delPicture'];
   }}}  

//удаление рисунка из pictures при редактировании
if (isset($_POST['picdelte'])) {
$ID =  $_POST['ID']; 
{if (($_POST['Picture']<>'') && file_exists("data/pictures/".$_POST['Picture']))
{$delPicture = mysqli_real_escape_string($link, $_POST['Picture']);
copy("data/pictures/".$_POST['Picture'], "data/del/".$_POST['Picture']); //перемещение в папку pictures
unlink ("data/pictures/".$_POST['Picture']);      //удаление файла из папки data/pictures/
$Picture = '';
$query = "UPDATE termin SET  
         Picture = '$Picture',
         delPicture = '$delPicture'
         WHERE ID = '$ID'";
  mysqli_query($link, $query);


   $qu   =  "SELECT Picture, delPicture FROM termin WHERE ID='$ID'";     
   $res  =  mysqli_query( $link,  $qu );
   $rw = mysqli_fetch_assoc($res); 
   $_POST['Picture'] = $rw['Picture'];
   $_POST['delPicture'] = $rw['delPicture'];
   }}}  

// выход из редактирования термина
 if (isset($_POST['extedt']))
{ $ID = $_POST['ID'];
  if ($_POST['Picture']<>'' && (file_exists("data/temp/".$_POST['Picture'])))
     {unlink ("data/temp/".$_POST['Picture']);
     $_POST['Picture'] = ''; 
     $query = "UPDATE termin SET  
         Picture = '' 
         WHERE ID = '$ID'";
      mysqli_query($link, $query);
   }

   if (file_exists("data/del/".$_POST['delPicture'] && $_POST['delPicture']<>''))
   {$Picture = mysqli_real_escape_string($link, $_POST['delPicture']);
    copy("data/del/".$_POST['delPicture'], "data/pictures/".$_POST['delPicture']); //перемещение в папку pictures
    unlink ("data/del/".$_POST['delPicture']);      //удаление файла из папки data/del/
    $query = "UPDATE termin SET 
         Picture = '$Picture',
         delPicture = '' 
         WHERE ID = '$ID'";
      mysqli_query($link, $query);}

  }



 echo "<table>
 <form  id='edqq' method = 'post' enctype='multipart/form-data'>
<input name='path1etd' type='hidden' value='", $_POST['path1etd'],"'>
<input name='ind' type='hidden' value='", $_POST['ind'],"'>
<input name='delPicture' type=hidden value='", $_POST['delPicture'],"'>
 <tr><input type='hidden' name='ID' size='20' value=",$_POST['ID']," readonly>
  <td><b>Термин:</b></td><td><textarea name='Name' rows='10' cols='40'>",$_POST['Name'],"</textarea></td>
   <td><b>Тувинский:</b></td><td><textarea name='Name_Tuv' rows='10' cols='40'>",$_POST['Name_Tuv'],"</textarea></td> 
   
   <td><b>Рисунок:</b></td>
   <td> <input type='file' name='filename'><br>";
    echo " <input name='Picture' type='text' size='10' value='", $_POST['Picture'],"' readonly><br>";
    echo " <input type='submit' name='load' value='Загрузить' >  ";
          {if (($_POST['Picture'] <> ''))
            { if (file_exists("data/temp/".$_POST['Picture']))
                  {echo "<input type='submit' name='temdelte' value='Удалить рисунок' formaction='#edt'><br><br>
                         <a href='data/temp/",$_POST['Picture'],"' target='_blank'><input type='button' value='Показать'></a><br><br>";
                  echo $_POST['rest'];}
                  else {if (file_exists("data/pictures/".$_POST['Picture']))
                  {echo "<input type='submit' name='picdelte' value='Удалить рисунок' formaction='#edt'><br><br>
                         <a href='data/pictures/",$_POST['Picture'],"' target='_blank'><input type='button' value='Показать'></a><br><br>";
                  echo $_POST['rest'];
                  }
                  }
            }

           }


  echo "</td></tr>
   
    <tr><td><b>Определение:</b></td><td><textarea name='Znach' rows='10' cols='40'>",$_POST['Znach'],"</textarea></td>
     <td><b>Тувинский:</b></td><td><textarea name='Znach_Tuv' rows='10' cols='40'>",$_POST['Znach_Tuv'],"</textarea></td>
       <td><b>Редактор:</b></td><td><input type='text' name='Avtor' size='20'  value='",$r['avtores'],"' readonly></td></tr>
 <tr><td colspan=6 align='center'><br><input type='submit',  name='save', value='Сохранить' formaction='term1.php'>
 <input form='edqq' type='submit' name='extedt' value='Вернуться назад' formaction='term1.php'><br></td></tr>
 </form></table>";
echo"</div> </div>";

 
//удаление строки
echo "<div id='delt' class='modalDialog'><div><a href='#close' title='Закрыть' class='close'>X</a>"; 
if (isset($_POST['delete'])) {

$ID = $_POST['ID'];  
$Name = $_POST['Name'];  
echo "<center><b><font align='center' size=3>Удаление математического термина № - ",$_POST['ind']," </b></font></center><br>";
 echo "<center><form method='post'>Вы действительно хотите удалить термин <b>",$Name,"</b>? 
 <br><br><input name='ID' type='hidden' value='", $ID ,"'><input name='Picture' type='hidden' value='", $_POST['Picture'] ,"'>
 <input type='submit' name='delt' value='Удалить' formaction='#delt'><input type='submit' value='Вернуться назад' formaction='term1.php'></form></center> ";
}
if (isset($_POST['delt'])) 
       {$ID = $_POST['ID']; 
        $query = "DELETE FROM termin WHERE ID = '$ID'";
        
        if ($_POST['Picture']<>''){
         if (file_exists("data/pictures/".$_POST['Picture']))
       {unlink ("data/pictures/".$_POST['Picture']);}}
       mysqli_query($link, $query); 
        echo "<center>Математический термин успешно удален!</center>";
       echo "<center><br><form action='term1.php' method='POST'>
       <input type='submit' value='Вернуться назад'></form></center>";
      } 
echo"</div> </div>"; 

//приветствие редактора
echo "<div id='user' class='modalDialog'><div><a href='#close' title='Закрыть' class='close'>X</a>";
echo "<center><font size=4>Добро пожаловать, <b><font color='red'>",$r['avtores'],".</font></b><br>
             Вы вошли как редактор.</font></center>";
echo"</div> </div>";  



if ( ( $_POST['search'] != '') && ( $_POST['search1'] != '')){

if (isset($_POST['search']) || isset($_POST['search1'])){

echo" <ul id='menu'>
      <li><a href='index.php'>Главная</a></li>
      <li><a href='term2.php'>Просмотр</a></li>
      <li><a href='#razrab'>Разработчики</a></li>
      <li><a href='#addition'>Добавить</a></li>
      <div class='auser'><a href='#exit'>Выход</a></div>
      <div class='auser'>Вы вошли как, <b><font color='blue'>",$r['avtores'],"</font></b></div>
       <div class='auser'><form method='POST' action='term1.php'>
<input type='search' placeholder='Поиск…' value='' name='search' size='30'>   <input type='submit' value='Найти' name='search1'></form></div>
<div class='auser'><a href='term1.php'>Назад</a></div>
</ul>";




$sea = mysqli_real_escape_string($link, $_POST['search'].'*');
    // работа с базой данных
 
         $query1   = "ALTER TABLE termin ADD FULLTEXT (Name, Name_Tuv, Znach, Znach_Tuv)";
         $query2   = "SELECT * FROM termin WHERE MATCH (Name, Name_Tuv, Znach, Znach_Tuv) AGAINST ('$sea' IN BOOLEAN MODE) ORDER BY termin.Name ASC";    
        
         mysqli_query( $link,  $query1 );
         $result  =  mysqli_query( $link,  $query2 );
         $count  =  mysqli_num_rows($result);

        echo "<br><center><b><font align='center' size=5>Редактирование словаря математических терминов</b></center></font><br>";
     // цикл по результирующему набору, пока не закончатся записи в наборе
         echo "<table border=1 bordercolor='green' width=100%>
         <caption><td  align='center' colspan=8><font size=5><b>Найдено совпадений ",$count,"</b></font></td></caption>
         <tr><td>№</td>
         <td align='center'>Термин</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Определение</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Рисунок</td>
         <td align='center'>Редактор</td>
         <td align='center'>Изменить</td></tr>";
         for ($i=1; $i<=$count; $i++) {
          $row = mysqli_fetch_assoc($result);
           echo "<tr><form method='POST'>";
         $id = mysqli_real_escape_string($link, $row['ID']);
                  echo " <input name='ind' type=hidden value='", $i ,"'>";
                   echo " <input name='delPicture' type=hidden value='", $row['delPicture'] ,"'>";
                  echo " <td><input name='ID' type=hidden value='", $row['ID'],"'>", $i,"</td>";
                  echo " <td><input name='Name' type=hidden value='", $row['Name'],"'>", $row['Name'],"</td>";   
                  echo " <td><input name='Name_Tuv' type=hidden value='", $row['Name_Tuv'],"'>", $row['Name_Tuv'],"</td>";
                  echo " <td><input name='Znach' type=hidden value='", $row['Znach'],"'>", $row['Znach'],"</td>";
                  echo " <td><input name='Znach_Tuv' type=hidden value='", $row['Znach_Tuv'],"'>", $row['Znach_Tuv'],"</td>";
                  
                   echo "<td>";
                 {if ($row['Picture'] <> '')
                 { if (file_exists("data/pictures/".$row['Picture']))
                  {echo "<input name='Picture' type='hidden' value=", $row['Picture'],"><br>
                  <a href='/data/pictures/", $row['Picture'],"' target='_blank'><input type='button' value='Показать'><br><br></a>";
                  }
                  else {echo "<input name='Picture' type='hidden' value=", $row['Picture'],"><br>
                  <a href='/data/pictures/", $row['Picture'],"' target='_blank'><input type='hidden' value='Показать'><br><br></a>";
                  }}}
                  echo "</td>";
                  
                  echo " <td><input name='Avtor' type='hidden' value=", $row['Avtor'],">", $row['Avtor'],"</td>";
                  echo " <td><br>
                        
                                       <input type='submit' name='edit' value='Изменить' formaction='#edt'><br><br>
                                       <input type='submit' name='delete' value='Удалить' formaction='#delt'>
                                       </td></form></tr>";
         }
         echo "</table>";
         
         }}
    else

{echo" <ul id='menu'>
      <li><a href='index.php'>Главная</a></li>
      <li><a href='term2.php'>Просмотр</a></li>
      <li><a href='#razrab'>Разработчики</a></li>
      <li><a href='#addition'>Добавить</a></li>
        <div class='auser'><a href='#exit'>Выход</a></div>
        <div class='auser'>Вы вошли как, <b><font color='blue'>",$r['avtores'],"</font></b></div>
        <div class='auser'><form method='POST' action='term1.php'>
<input type='search' placeholder='Поиск…' value='' name='search' size='30'>   <input type='submit' value='Найти' name='search1'></form></div>
</ul>";

     // работа с базой данных
         $query   =  "SELECT * FROM termin ORDER BY termin.Name ASC";     $result  =  mysqli_query( $link,  $query );
         $count  =  mysqli_num_rows($result);
        echo "<br><center><b><font align='center' size=5>Редактирование словаря математических терминов</b></center></font><br>";
     // цикл по результирующему набору, пока не закончатся записи в наборе
         echo "<table border=1 bordercolor='green' width=100%>
         <caption><td  align='center' colspan=8><font size=5><b>Математические термины (всего - ",$count,")</b></font></td></caption>
         <tr><td>№</td>
         <td align='center'>Термин</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Определение</td>
         <td align='center'>Тувинский</td>
         <td align='center'>Рисунок</td>
         <td align='center'>Редактор</td>
         <td align='center'>Изменить</td></tr>";
         for ($i=1; $i<=$count; $i++) {
          $row = mysqli_fetch_assoc($result);
           echo "<tr><form method='POST'>";
         $id = mysqli_real_escape_string($link, $row['ID']);
                  echo "<input name='ind' type=hidden value='", $i,"'>";
                   echo "<input name='delPicture' type=hidden value='", $row['delPicture'],"'>";
                  echo " <td><input name='ID' type=hidden value='", $row['ID'],"'>", $i,"</td>";
                  echo " <td><input name='Name' type=hidden value='", $row['Name'],"'>", $row['Name'],"</td>";   
                  echo " <td><input name='Name_Tuv' type=hidden value='", $row['Name_Tuv'],"'>", $row['Name_Tuv'],"</td>";
                  echo " <td><input name='Znach' type=hidden value='", $row['Znach'],"'>", $row['Znach'],"</td>";
                  echo " <td><input name='Znach_Tuv' type=hidden value='", $row['Znach_Tuv'],"'>", $row['Znach_Tuv'],"</td>";
                  
                   echo "<td>";
                 {if ($row['Picture'] <> '')
                 { if (file_exists("data/pictures/".$row['Picture']))
                  {echo "<input name='Picture' type='hidden' value=", $row['Picture'],"><br>
                  <a href='/data/pictures/", $row['Picture'],"' target='_blank'><input type='button' value='Показать'><br><br></a>";
                  }
                  else {echo "<input name='Picture' type='hidden' value=", $row['Picture'],"><br>
                  <a href='/data/pictures/", $row['Picture'],"' target='_blank'><input type='hidden' value='Показать'><br><br></a>";
                  }}}
                  echo "</td>";
                  
                  echo " <td><input name='Avtor' type='hidden' value=", $row['Avtor'],">", $row['Avtor'],"</td>";
                  echo " <td><br>
                        
                                       <input type='submit' name='edit' value='Изменить' formaction='#edt'><br><br>
                                       <input type='submit' name='delete' value='Удалить' formaction='#delt'>
                                       </td></form></tr>";
         }
         echo "
         <tr><td></td>
         <td></td>
         <td></td>
         <td></td>
         <td></td>
         <td></td>
         <td></td>
         <td><br><form method='POST'>
                 <input type='submit' name='addterm' value='Добавить' formaction='#addition'><br></form></td></tr></table>";


    }
         
         mysqli_free_result($z);
         mysqli_free_result($result);           // очищаем память
         mysqli_close($link);                       // закрываем базу
             
         
         
     }   
    else 
        {echo "<script>document.location.replace('index.php')</script>";
        }}
    else {echo "<script>document.location.replace('index.php')</script>";
    }
      
?>
  </body>
</html>